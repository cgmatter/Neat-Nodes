# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Neat Nodes",
    "author" : "CGMatter", 
    "description" : "",
    "blender" : (4, 3, 0),
    "version" : (1, 0, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Node" 
}


import bpy
import bpy.utils.previews
from bpy.app.handlers import persistent
import mathutils
import blf
import math
from datetime import datetime
import gpu
import gpu_extras
import os


addon_keymaps = {}
_icons = None
neat_reroute = {'sna_reroute_location': None, 'sna_active_reroute': None, }
neat_view = {'sna_doubleclick_time': 0.0, 'sna_viewer_on': False, }


def find_user_keyconfig(key):
    km, kmi = addon_keymaps[key]
    for item in bpy.context.window_manager.keyconfigs.user.keymaps[km.name].keymap_items:
        found_item = False
        if kmi.idname == item.idname:
            found_item = True
            for name in dir(kmi.properties):
                if not name in ["bl_rna", "rna_type"] and not name[0] == "_":
                    if name in kmi.properties and name in item.properties and not kmi.properties[name] == item.properties[name]:
                        found_item = False
        if found_item:
            return item
    print(f"Couldn't find keymap item for {key}, using addon keymap instead. This won't be saved across sessions!")
    return kmi


def coords_region_to_view(area, coords):
    for region in area.regions:
        if region.type == "WINDOW":
            ui_scale = bpy.context.preferences.system.ui_scale
            x, y = region.view2d.region_to_view(coords[0], coords[1])
            return (x/ui_scale, y/ui_scale)
    return coords


class dotdict(dict):
    __getattr__ = dict.get
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__


def find_areas_of_type(screen, area_type):
    areas = []
    for area in screen.areas:
        if area.type == area_type:
            areas.append(area)
    return areas


def get_text_dimensions(text, font, size, dpi):
    font_id = 0
    if font and os.path.exists(font):
        font_id = blf.load(font)
    if font_id == -1:
        print("Couldn't load font!")
    else:
        if bpy.app.version >= (3, 4, 0):
            blf.size(font_id, size)
        else:
            blf.size(font_id, size, dpi)
    return blf.dimensions(font_id, text)


def coords_view_to_region(area, coords):
    for region in area.regions:
        if region.type == "WINDOW":
            ui_scale = bpy.context.preferences.system.ui_scale
            return region.view2d.view_to_region(coords[0]*ui_scale, coords[1]*ui_scale, clip=False)
    return coords


def get_zoom_level(area):
    ui_scale = bpy.context.preferences.system.ui_scale
    for region in area.regions:
        if region.type == "WINDOW":
            test_length = 1000
            x0, y0 = region.view2d.view_to_region(0, 0, clip=False)
            x1, y1 = region.view2d.view_to_region(test_length, test_length, clip=False)
            xl = x1 - x0
            yl = y1 - y0
            return (math.sqrt(xl**2 + yl**2) / test_length) * ui_scale
    return 1 * ui_scale


class SNA_OT_Set_Node_Color_A19F3(bpy.types.Operator):
    bl_idname = "sna.set_node_color_a19f3"
    bl_label = "Set Node Color"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_color: bpy.props.FloatVectorProperty(name='Color', description='', size=3, default=(0.0, 0.0, 0.0), subtype='NONE', unit='NONE', step=3, precision=6)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_5E09D in range(len(bpy.context.selected_nodes)):
            bpy.context.selected_nodes[i_5E09D].use_custom_color = True
            bpy.context.selected_nodes[i_5E09D].color = self.sna_color
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Clear_Node_Color_C3730(bpy.types.Operator):
    bl_idname = "sna.clear_node_color_c3730"
    bl_label = "Clear Node Color"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_9DEB8 in range(len(bpy.context.selected_nodes)):
            bpy.context.selected_nodes[i_9DEB8].use_custom_color = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_MT_5A506(bpy.types.Menu):
    bl_idname = "SNA_MT_5A506"
    bl_label = "Neat Nodes"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.menu_pie()
        col_B2F22 = layout.column(heading='', align=False)
        col_B2F22.alert = False
        col_B2F22.enabled = True
        col_B2F22.active = True
        col_B2F22.use_property_split = False
        col_B2F22.use_property_decorate = False
        col_B2F22.scale_x = 1.0
        col_B2F22.scale_y = 2.0
        col_B2F22.alignment = 'Expand'.upper()
        col_B2F22.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_B2F22.operator('sna.neat_nodes_operator_91e12', text='View', icon_value=13, emboss=True, depress=neat_view['sna_viewer_on'])
        col_8205D = layout.column(heading='', align=False)
        col_8205D.alert = False
        col_8205D.enabled = True
        col_8205D.active = True
        col_8205D.use_property_split = False
        col_8205D.use_property_decorate = False
        col_8205D.scale_x = 1.0
        col_8205D.scale_y = 2.0
        col_8205D.alignment = 'Expand'.upper()
        col_8205D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_8205D.operator('sna.neat_reroute_2a11d', text='Reroute', icon_value=82, emboss=True, depress=False)
        col_5B128 = layout.column(heading='', align=True)
        col_5B128.alert = False
        col_5B128.enabled = True
        col_5B128.active = True
        col_5B128.use_property_split = False
        col_5B128.use_property_decorate = False
        col_5B128.scale_x = 1.0
        col_5B128.scale_y = 1.0
        col_5B128.alignment = 'Expand'.upper()
        col_5B128.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_5B128.operator('sna.clear_node_color_c3730', text='Clear', icon_value=70, emboss=True, depress=False)
        grid_10149 = col_5B128.grid_flow(columns=3, row_major=True, even_columns=True, even_rows=True, align=True)
        grid_10149.enabled = True
        grid_10149.active = True
        grid_10149.use_property_split = False
        grid_10149.use_property_decorate = False
        grid_10149.alignment = 'Expand'.upper()
        grid_10149.scale_x = 1.0
        grid_10149.scale_y = 1.0
        if not True: grid_10149.operator_context = "EXEC_DEFAULT"
        op = grid_10149.operator('sna.set_node_color_a19f3', text='', icon_value=781, emboss=True, depress=False)
        op.sna_color = (0.6499999761581421, 0.15000000596046448, 0.15000000596046448)
        op = grid_10149.operator('sna.set_node_color_a19f3', text='', icon_value=782, emboss=True, depress=False)
        op.sna_color = (0.6499999761581421, 0.4000000059604645, 0.15000000596046448)
        op = grid_10149.operator('sna.set_node_color_a19f3', text='', icon_value=783, emboss=True, depress=False)
        op.sna_color = (0.699999988079071, 0.5799999833106995, 0.0)
        op = grid_10149.operator('sna.set_node_color_a19f3', text='', icon_value=784, emboss=True, depress=False)
        op.sna_color = (0.25, 0.6000000238418579, 0.15000000596046448)
        op = grid_10149.operator('sna.set_node_color_a19f3', text='', icon_value=785, emboss=True, depress=False)
        op.sna_color = (0.15000000596046448, 0.6000000238418579, 0.6000000238418579)
        op = grid_10149.operator('sna.set_node_color_a19f3', text='', icon_value=786, emboss=True, depress=False)
        op.sna_color = (0.44999998807907104, 0.15000000596046448, 0.6000000238418579)
        op = grid_10149.operator('sna.set_node_color_a19f3', text='', icon_value=787, emboss=True, depress=False)
        op.sna_color = (0.6000000238418579, 0.25, 0.4000000059604645)
        op = grid_10149.operator('sna.set_node_color_a19f3', text='', icon_value=788, emboss=True, depress=False)
        op.sna_color = (0.5, 0.30000001192092896, 0.20000000298023224)
        op = grid_10149.operator('sna.set_node_color_a19f3', text='', icon_value=789, emboss=True, depress=False)
        op.sna_color = (0.30000001192092896, 0.30000001192092896, 0.30000001192092896)


class SNA_AddonPreferences_88A36(bpy.types.AddonPreferences):
    bl_idname = __package__

    def draw(self, context):
        if not (False):
            layout = self.layout 
            layout.prop(find_user_keyconfig('898F0'), 'type', text='Hotkey', full_event=True)


@persistent
def load_pre_handler_52116(dummy):
    bpy.ops.preferences.addon_enable('INVOKE_DEFAULT', module='node_wrangler')


class SNA_OT_Neat_Reroute_2A11D(bpy.types.Operator):
    bl_idname = "sna.neat_reroute_2a11d"
    bl_label = "Neat Reroute"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.node.nw_add_reroutes('INVOKE_DEFAULT', option='LINKED')
        neat_reroute['sna_active_reroute'] = bpy.context.active_node
        neat_reroute['sna_reroute_location'] = bpy.context.active_node.location
        bpy.ops.node.nw_add_reroutes(option='LINKED')
        bpy.context.active_node.location = neat_reroute['sna_reroute_location']
        bpy.ops.sna.shift_y_3a3e7('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


_3A3E7_running = False
class SNA_OT_Shift_Y_3A3E7(bpy.types.Operator):
    bl_idname = "sna.shift_y_3a3e7"
    bl_label = "Shift Y"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    cursor = "DEFAULT"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not False or context.area.spaces[0].bl_rna.identifier == 'SpaceNodeEditor':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _3A3E7_running
        _3A3E7_running = False
        context.window.cursor_set("DEFAULT")
        bpy.ops.sna.shift_x_0fafe('INVOKE_DEFAULT', )
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _3A3E7_running
        if not context.area or not _3A3E7_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.window.cursor_set('DEFAULT')
        try:
            bpy.context.active_node.location = tuple(mathutils.Vector(tuple(mathutils.Vector(bpy.context.active_node.location) * mathutils.Vector((1.0, 0.0)))) + mathutils.Vector(tuple(mathutils.Vector(coords_region_to_view(bpy.context.area, tuple((event.mouse_region_x, event.mouse_region_y)))) * mathutils.Vector((0.0, 1.0)))))
            if (event.type == 'LEFTMOUSE' and event.value == 'PRESS' and event.alt == False and event.shift == False and event.ctrl == False):
                if event.type in ['RIGHTMOUSE', 'ESC']:
                    self.execute(context)
                    return {'CANCELLED'}
                self.execute(context)
                return {"FINISHED"}
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global _3A3E7_running
        if _3A3E7_running:
            _3A3E7_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            context.window_manager.modal_handler_add(self)
            _3A3E7_running = True
            return {'RUNNING_MODAL'}


_0FAFE_running = False
class SNA_OT_Shift_X_0Fafe(bpy.types.Operator):
    bl_idname = "sna.shift_x_0fafe"
    bl_label = "Shift X"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    cursor = "DEFAULT"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not False or context.area.spaces[0].bl_rna.identifier == 'SpaceNodeEditor':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _0FAFE_running
        _0FAFE_running = False
        context.window.cursor_set("DEFAULT")
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _0FAFE_running
        if not context.area or not _0FAFE_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.window.cursor_set('DEFAULT')
        try:
            for i_C0BB2 in range(len(bpy.context.selected_nodes)):
                bpy.context.selected_nodes[i_C0BB2].location = tuple(mathutils.Vector(tuple(mathutils.Vector(bpy.context.selected_nodes[i_C0BB2].location) * mathutils.Vector((0.0, 1.0)))) + mathutils.Vector(tuple(mathutils.Vector(coords_region_to_view(bpy.context.area, tuple((event.mouse_region_x, event.mouse_region_y)))) * mathutils.Vector((1.0, 0.0)))))
                if (event.type == 'LEFTMOUSE' and event.value == 'PRESS' and event.alt == False and event.shift == False and event.ctrl == False):
                    if event.type in ['RIGHTMOUSE', 'ESC']:
                        self.execute(context)
                        return {'CANCELLED'}
                    self.execute(context)
                    return {"FINISHED"}
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global _0FAFE_running
        if _0FAFE_running:
            _0FAFE_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            neat_reroute['sna_active_reroute'].select = True
            context.window_manager.modal_handler_add(self)
            _0FAFE_running = True
            return {'RUNNING_MODAL'}


def sna_add_to_node_mt_context_menu_C2A62(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sna.neat_reroute_2a11d', text='Neat Reroute', icon_value=82, emboss=True, depress=False)


_91E12_running = False
class SNA_OT_Neat_Nodes_Operator_91E12(bpy.types.Operator):
    bl_idname = "sna.neat_nodes_operator_91e12"
    bl_label = "Neat Nodes Operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    cursor = "DEFAULT"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not True or context.area.spaces[0].bl_rna.identifier == 'SpaceNodeEditor':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                for i_A7690 in range(len(bpy.context.area.spaces[0].edit_tree.nodes)):
                    if ('REROUTE' != bpy.context.area.spaces[0].edit_tree.nodes[i_A7690].type):
                        coords = (tuple(mathutils.Vector(tuple(mathutils.Vector((0.0, float(get_zoom_level(bpy.context.area) * 10.0))) + mathutils.Vector(coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].edit_tree.nodes[i_A7690].location))))) + mathutils.Vector((0.0, float(float(get_zoom_level(bpy.context.area) * 10.0) * -0.10000000149011612)))), )
                        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
                        batch = gpu_extras.batch.batch_for_shader(shader, 'POINTS', {"pos": coords})
                        shader.bind()
                        shader.uniform_float("color", (1.0, 1.0, 1.0, 1.0))
                        gpu.state.point_size_set(float(get_text_dimensions(bpy.context.area.spaces[0].edit_tree.nodes[i_A7690].name, r'', float(get_zoom_level(bpy.context.area) * 10.0), 72)[1] / 3.0))
                        gpu.state.depth_test_set('NONE')
                        gpu.state.depth_mask_set(True)
                        gpu.state.blend_set('ALPHA')
                        batch.draw(shader)
                        font_id = 0
                        if r'' and os.path.exists(r''):
                            font_id = blf.load(r'')
                        if font_id == -1:
                            print("Couldn't load font!")
                        else:
                            x_09464, y_09464 = tuple(mathutils.Vector(tuple(mathutils.Vector((get_text_dimensions(bpy.context.area.spaces[0].edit_tree.nodes[i_A7690].name, r'', float(get_zoom_level(bpy.context.area) * 10.0), 72)[1], float(get_text_dimensions(bpy.context.area.spaces[0].edit_tree.nodes[i_A7690].name, r'', float(get_zoom_level(bpy.context.area) * 10.0), 72)[1] / -2.0))) + mathutils.Vector(tuple(mathutils.Vector((0.0, float(get_zoom_level(bpy.context.area) * 10.0))) + mathutils.Vector(coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].edit_tree.nodes[i_A7690].location))))))) - mathutils.Vector((float(get_zoom_level(bpy.context.area) * 2.0), 0.0)))
                            blf.position(font_id, x_09464, y_09464, 0)
                            if bpy.app.version >= (3, 4, 0):
                                blf.size(font_id, float(get_zoom_level(bpy.context.area) * 10.0))
                            else:
                                blf.size(font_id, float(get_zoom_level(bpy.context.area) * 10.0), 72)
                            clr = (1.0, 1.0, 1.0, 0.5)
                            blf.color(font_id, clr[0], clr[1], clr[2], clr[3])
                            if 1000:
                                blf.enable(font_id, blf.WORD_WRAP)
                                blf.word_wrap(font_id, 1000)
                            if 0.0:
                                blf.enable(font_id, blf.ROTATION)
                                blf.rotation(font_id, 0.0)
                            blf.enable(font_id, blf.WORD_WRAP)
                            blf.draw(font_id, bpy.context.area.spaces[0].edit_tree.nodes[i_A7690].name)
                            blf.disable(font_id, blf.ROTATION)
                            blf.disable(font_id, blf.WORD_WRAP)
                        font_id = 0
                        if r'' and os.path.exists(r''):
                            font_id = blf.load(r'')
                        if font_id == -1:
                            print("Couldn't load font!")
                        else:
                            x_55C05, y_55C05 = (10.0, 12.5)
                            blf.position(font_id, x_55C05, y_55C05, 0)
                            if bpy.app.version >= (3, 4, 0):
                                blf.size(font_id, 10.0)
                            else:
                                blf.size(font_id, 10.0, 72)
                            clr = (1.0, 1.0, 1.0, 0.20000000298023224)
                            blf.color(font_id, clr[0], clr[1], clr[2], clr[3])
                            if 1000:
                                blf.enable(font_id, blf.WORD_WRAP)
                                blf.word_wrap(font_id, 1000)
                            if 0.0:
                                blf.enable(font_id, blf.ROTATION)
                                blf.rotation(font_id, 0.0)
                            blf.enable(font_id, blf.WORD_WRAP)
                            blf.draw(font_id, bpy.context.area.spaces[0].edit_tree.name_full + ' | ' + str(len(bpy.context.area.spaces[0].edit_tree.nodes)) + ' Nodes')
                            blf.disable(font_id, blf.ROTATION)
                            blf.disable(font_id, blf.WORD_WRAP)
            except Exception as error:
                print(error)

    def execute(self, context):
        global _91E12_running
        _91E12_running = False
        context.window.cursor_set("DEFAULT")
        bpy.types.SpaceNodeEditor.draw_handler_remove(self._handle, 'WINDOW')
        neat_view['sna_viewer_on'] = False
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _91E12_running
        if not context.area or not _91E12_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.area.tag_redraw()
        context.window.cursor_set('DEFAULT')
        try:
            if ( not bool(find_areas_of_type(bpy.context.screen, 'NODE_EDITOR')) or (event.type == 'ESC')):
                neat_view['sna_viewer_on'] = False
                self.execute(context)
                return {"FINISHED"}
            else:
                if ((event.value == 'RELEASE') and (event.type == 'LEFT_SHIFT')):
                    if ((float(eval("1000*(3600*datetime.now().time().hour + 60*datetime.now().time().minute + datetime.now().time().second) + datetime.now().time().microsecond//1000") - neat_view['sna_doubleclick_time']) > 50.0) and (float(eval("1000*(3600*datetime.now().time().hour + 60*datetime.now().time().minute + datetime.now().time().second) + datetime.now().time().microsecond//1000") - neat_view['sna_doubleclick_time']) < 300.0)):
                        neat_view['sna_doubleclick_time'] = 0.0
                        bpy.ops.wm.call_panel(name="SNA_PT_NEAT_NAMES_497D6", keep_open=False)
                    else:
                        neat_view['sna_doubleclick_time'] = eval("1000*(3600*datetime.now().time().hour + 60*datetime.now().time().minute + datetime.now().time().second) + datetime.now().time().microsecond//1000")
        except Exception as error:
            print(error)
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global _91E12_running
        if _91E12_running:
            _91E12_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            neat_view['sna_doubleclick_time'] = eval("1000*(3600*datetime.now().time().hour + 60*datetime.now().time().minute + datetime.now().time().second) + datetime.now().time().microsecond//1000")
            neat_view['sna_viewer_on'] = True
            args = (context,)
            self._handle = bpy.types.SpaceNodeEditor.draw_handler_add(self.draw_callback_px, args, 'WINDOW', 'POST_PIXEL')
            context.window_manager.modal_handler_add(self)
            _91E12_running = True
            return {'RUNNING_MODAL'}


def sna_add_to_node_ht_header_38CC4(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sna.neat_nodes_operator_91e12', text='', icon_value=397, emboss=True, depress=neat_view['sna_viewer_on'])


class SNA_PT_NEAT_NAMES_497D6(bpy.types.Panel):
    bl_label = 'Neat Names'
    bl_idname = 'SNA_PT_NEAT_NAMES_497D6'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.prop(bpy.context.active_node, 'name', text='', icon_value=0, emboss=True)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_OT_Set_Node_Color_A19F3)
    bpy.utils.register_class(SNA_OT_Clear_Node_Color_C3730)
    bpy.utils.register_class(SNA_MT_5A506)
    bpy.utils.register_class(SNA_AddonPreferences_88A36)
    bpy.app.handlers.load_pre.append(load_pre_handler_52116)
    bpy.utils.register_class(SNA_OT_Neat_Reroute_2A11D)
    bpy.utils.register_class(SNA_OT_Shift_Y_3A3E7)
    bpy.utils.register_class(SNA_OT_Shift_X_0Fafe)
    bpy.types.NODE_MT_context_menu.prepend(sna_add_to_node_mt_context_menu_C2A62)
    bpy.utils.register_class(SNA_OT_Neat_Nodes_Operator_91E12)
    bpy.types.NODE_HT_header.append(sna_add_to_node_ht_header_38CC4)
    bpy.utils.register_class(SNA_PT_NEAT_NAMES_497D6)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Node Editor', space_type='NODE_EDITOR')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'Q', 'ANY',
        ctrl=True, alt=False, shift=True, repeat=False)
    kmi.properties.name = 'SNA_MT_5A506'
    addon_keymaps['898F0'] = (km, kmi)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_OT_Set_Node_Color_A19F3)
    bpy.utils.unregister_class(SNA_OT_Clear_Node_Color_C3730)
    bpy.utils.unregister_class(SNA_MT_5A506)
    bpy.utils.unregister_class(SNA_AddonPreferences_88A36)
    bpy.app.handlers.load_pre.remove(load_pre_handler_52116)
    bpy.utils.unregister_class(SNA_OT_Neat_Reroute_2A11D)
    bpy.utils.unregister_class(SNA_OT_Shift_Y_3A3E7)
    bpy.utils.unregister_class(SNA_OT_Shift_X_0Fafe)
    bpy.types.NODE_MT_context_menu.remove(sna_add_to_node_mt_context_menu_C2A62)
    bpy.utils.unregister_class(SNA_OT_Neat_Nodes_Operator_91E12)
    bpy.types.NODE_HT_header.remove(sna_add_to_node_ht_header_38CC4)
    bpy.utils.unregister_class(SNA_PT_NEAT_NAMES_497D6)
